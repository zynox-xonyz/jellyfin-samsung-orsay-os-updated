var ServerVersion = {
		ServerInfo : null
}

ServerVersion.start = function() {
	document.getElementById("pageContent").innerHTML = "<div class='padding60' style='text-align:center'> \
		<p style='padding-bottom:5px;'>The Samsung app requires a later version of the Server - Please update it and restart the app</p>";
	
	document.getElementById("ServerVersion").focus();
}

ServerVersion.checkServerVersion = function() {
	var url = Server.getCustomURL("/System/Info/Public?format=json");
	this.ServerInfo = Server.getContent(url);
	if (this.ServerInfo == null) { return false; }

	var requiredServerVersion = Main.getRequiredServerVersion();
	var currentServerVersion = this.ServerInfo.Version;

	// Numeric compare - a plain string ">=" fails for versions like
	// "10.10.x" because it compares character by character ('1' < '3').
	return ServerVersion.compareVersions(currentServerVersion, requiredServerVersion) >= 0;
}

// Returns 1 if a > b, -1 if a < b, 0 if equal. Dotted numeric versions.
ServerVersion.compareVersions = function(a, b) {
	var pa = String(a).split(".");
	var pb = String(b).split(".");
	var len = Math.max(pa.length, pb.length);
	for (var i = 0; i < len; i++) {
		var na = parseInt(pa[i], 10); if (isNaN(na)) { na = 0; }
		var nb = parseInt(pb[i], 10); if (isNaN(nb)) { nb = 0; }
		if (na > nb) { return 1; }
		if (na < nb) { return -1; }
	}
	return 0;
}

ServerVersion.keyDown = function() {
	var keyCode = event.keyCode;

	if (document.getElementById("Notifications").style.visibility == "") {
		document.getElementById("Notifications").style.visibility = "hidden";
		document.getElementById("NotificationText").innerHTML = "";
		widgetAPI.blockNavigation(event);
		//Change keycode so it does nothing!
		keyCode = "VOID";
	}
	
	switch(keyCode) {
		default:
			widgetAPI.sendExitEvent();
			break;
	}
}